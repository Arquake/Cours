package controleur.ordres;

public enum TypeOrdre {
    // Type des ordres
     SHOW_CHEVAUX,
     SHOW_ENREGISTREMENT,
     SHOW_DETAIL,
    SELECTION_CHEVAL,
    LOAD_CHEVAUX,
    NOUVEAU_CHEVAL,
    ERREUR_CHEVAL_EXISTANT
 }
