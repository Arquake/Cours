package controleur;

import vues.GestionnaireVue;

public interface ControleurSetUp {

    void setUp(ControleurImpl controleur, GestionnaireVue gestionnaireVue);
}
