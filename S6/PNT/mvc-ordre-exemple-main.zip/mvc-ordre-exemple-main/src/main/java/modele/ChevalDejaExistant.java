package modele;

public class ChevalDejaExistant extends Exception {
}
