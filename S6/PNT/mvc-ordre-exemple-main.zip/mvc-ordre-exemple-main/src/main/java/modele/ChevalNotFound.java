package modele;

public class ChevalNotFound extends Exception {
}
