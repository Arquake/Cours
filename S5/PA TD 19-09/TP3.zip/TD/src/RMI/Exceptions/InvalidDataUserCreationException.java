package RMI.Exceptions;

public class InvalidDataUserCreationException extends Exception{
    public InvalidDataUserCreationException() {
        super("Les informations pour créer l'utilisateur ne sont pas valides");
    }

    @Override
    public String getMessage() {
        return super.getMessage();
    }
}
