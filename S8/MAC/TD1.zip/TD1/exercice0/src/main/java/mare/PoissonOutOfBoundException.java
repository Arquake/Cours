package mare;

public class PoissonOutOfBoundException extends Exception {
}
