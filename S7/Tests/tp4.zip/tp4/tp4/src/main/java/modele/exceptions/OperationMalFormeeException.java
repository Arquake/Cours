package modele.exceptions;

public class OperationMalFormeeException extends Exception {
}
